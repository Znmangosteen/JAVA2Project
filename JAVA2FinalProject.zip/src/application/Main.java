/**
65985869 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */


package application;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javax.print.DocFlavor.URL;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;


public class Main extends Application implements Initializable  {
	ArrayList<EarthQuack_info> arlist = new ArrayList<>();//��ArrayList����װString�������洢����
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("../earthquakeUI.fxml"));
			primaryStage.setTitle("�����ѯС����");
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
			System.err.println("���ڳ�ʼ��");
			System.exit(0);
		}
	}
	@FXML
	TableView<EarthQuack_info> earthquackTable;

	@FXML
	TableColumn<EarthQuack_info,?> IDcol = new TableColumn<>("ID");

	@FXML
	TableColumn<EarthQuack_info,?> UTC_datecol= new TableColumn<>("UTC_date");

	@FXML
	TableColumn<EarthQuack_info,?> latitudecol= new TableColumn<>("latitude");

	@FXML
	TableColumn<EarthQuack_info,?> longitudecol= new TableColumn<>("longitude");

	@FXML
	TableColumn<EarthQuack_info,?> depthcol= new TableColumn<>("depth");

	@FXML
	TableColumn<EarthQuack_info,?> magnitudecol= new TableColumn<>("magnitude");

	@FXML
	TableColumn<EarthQuack_info,?> regioncol= new TableColumn<>("region");

	@FXML
	Canvas canvas ;
	GraphicsContext gc ;
	
	@FXML
	Tab maptab;

	@FXML
	TextField place;

	@FXML
	Button search,clear;

	@FXML
	Slider slider;

	@FXML
	DatePicker dp1,dp2;
	
	ObservableList<EarthQuack_info> data;
	@SuppressWarnings("unchecked")
	
	@Override
	public void initialize(java.net.URL location,ResourceBundle resources){
		try {  
			BufferedReader reader = new BufferedReader(new FileReader("earthquakes.csv"));//��������ļ��� 
			reader.readLine();//��һ��Ϊ������Ϣ,ע�͵� 
			String line = null;  

			while((line=reader.readLine())!=null){  
				String item[] = line.split(",");//CSV��ʽ�ļ�Ϊ���ŷָ����ļ���������ݶ����з� 
				EarthQuack_info eri = new EarthQuack_info
						(item[0], item[1], item[2], item[3], item[4], item[5], item[6]);
				arlist.add(eri);

			}  
		} catch (Exception e) {  
			e.printStackTrace(); 
			System.err.println("shujuduru");
		}  


		//all the table view stuff
		data = FXCollections.observableArrayList(arlist);
		earthquackTable.setEditable(true);
		earthquackTable.getColumns().addAll
		(IDcol,UTC_datecol,latitudecol,longitudecol,depthcol,magnitudecol,regioncol);

		IDcol.setCellValueFactory(new PropertyValueFactory<>("ID"));
		UTC_datecol.setCellValueFactory(new PropertyValueFactory<>("UTC_date"));
		latitudecol.setCellValueFactory(new PropertyValueFactory<>("latitude"));
		longitudecol.setCellValueFactory(new PropertyValueFactory<>("longitude"));
		depthcol.setCellValueFactory(new PropertyValueFactory<>("depth"));
		magnitudecol.setCellValueFactory(new PropertyValueFactory<>("magnitude"));
		regioncol.setCellValueFactory(new PropertyValueFactory<>("region"));
		try{
			earthquackTable.setItems(data);
		}catch (Exception e) {
			System.err.println("adding info");
			System.exit(1);
		}


		//all the picture drawing
		gc = canvas.getGraphicsContext2D();
		gc.setStroke(Color.RED);
		double w = canvas.getWidth();
		double h = canvas.getHeight();
		for (EarthQuack_info ind : arlist) {
			double lon = Double.parseDouble(ind.getLongtitude());
			double lan = Double.parseDouble(ind.getLantitude());
			double x = (lon>=0)?lon*w/360:(180-lon)*w/360;
			double y = (90-lan)*h/180;
			gc.strokeOval(x, y, 2, 2);
		}


		//all the day picker stuff
		dp1.setValue(LocalDate.now());
		dp2.setValue(LocalDate.now().plusDays(1));
		final Callback<DatePicker, DateCell> dayCellFactory = 
				new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						if (item.isBefore(
								dp1.getValue().plusDays(1))
								) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}   
					}
				};
			}
		};
		dp2.setDayCellFactory(dayCellFactory);
		dp2.setValue(dp1.getValue().plusDays(1));
	}
	public static void main(String[] args) {
		launch(args);
	}


	//all the button stuff
	public void onSearch(MouseEvent e) throws ParseException{
		data.clear();
		gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
		//�б����
		String beginDate = dp1.getValue().toString();
		String endDate = dp2.getValue().toString();
		Date bd = new SimpleDateFormat("yyyy-MM-dd").parse(beginDate);
		Date ed = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
		String placeinfo= place.getText();
		double mag = slider.getValue();
		ArrayList<EarthQuack_info> temp = new ArrayList<>();
		for (EarthQuack_info ind : arlist) {
			String currentDate = ind.getUTC_date().substring(0, 10);
			Date d = new SimpleDateFormat("yyyy/MM/dd").parse(currentDate);
			if((d.equals(ed)||d.equals(bd))||(d.before(ed)&&d.after(bd)) 
					&&ind.getRegion().contains(placeinfo)
					&&(Double.parseDouble(ind.getMagnitude()) >= mag)){
				//��ͼ
				double w = canvas.getWidth();
				double h = canvas.getHeight();
					double lon = Double.parseDouble(ind.getLongtitude());
					double lan = Double.parseDouble(ind.getLantitude());
					double x = (lon>=0)?lon*w/360:(180-lon)*w/360;
					double y = (90-lan)*h/180;
					gc.strokeOval(x, y, 2, 2);
				//��������
				data.add(ind);
			}
		}
		earthquackTable.setItems(data);
	}

	public void onClear(MouseEvent me){
		dp1.setValue(LocalDate.now());
		dp2.setValue(dp1.getValue().plusDays(1));
//		gc.clearRect(0, 0, canvas.getWidth(), h);
		place.clear();
		data = FXCollections.observableArrayList(arlist);
		earthquackTable.setItems(data);
	}

}

